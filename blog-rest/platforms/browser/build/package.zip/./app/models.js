var publicacionModel = Backbone.Model.extend({
	urlRoot: 'http://104.236.245.239/api/publicaciones/'
}
);
